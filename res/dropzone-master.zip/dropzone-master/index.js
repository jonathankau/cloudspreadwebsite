

/**
 * Exposing dropzone
 */
module.exports = require("./lib/dropzone.js");
